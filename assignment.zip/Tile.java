package test;


public class Tile {

	
}
